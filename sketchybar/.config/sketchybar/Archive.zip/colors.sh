#!/bin/bash

# Base palette
export WHITE=0xffffffff
export BLACK=0xff000000

# -- Slate Dark Scheme (active) --
# export BAR_COLOR=0xcc1a1b26       # near-black, slightly transparent
# export ITEM_BG_COLOR=0xff2a2b3d   # muted navy-slate for all items
# export ACCENT_COLOR=0xff7aa2f7    # soft blue accent (Tokyo Night-inspired)
export LABEL_COLOR=0xffcdd6f4 # off-white labels
export ICON_COLOR=0xff7aa2f7  # matches accent
export DIM_COLOR=0xff565f89   # muted/secondary text

# -- Teal Scheme --
# export BAR_COLOR=0x00000000
# export ITEM_BG_COLOR=0xff405f3e
# export ACCENT_COLOR=0xff405f3e

# -- Gray Scheme --
# export BAR_COLOR=0xff101314
export ITEM_BG_COLOR=0xff353c3f
export ACCENT_COLOR=0xffffffff
# #D3EED8

# -- Purple Scheme --
# export BAR_COLOR=0xff140c42
# export ITEM_BG_COLOR=0xff2b1c84
# export ACCENT_COLOR=0xffeb46f9

# -- Red Scheme ---
# export BAR_COLOR=0xff23090e
# export ITEM_BG_COLOR=0xff591221
# export ACCENT_COLOR=0xffff2453

# -- Blue Scheme ---
# export BAR_COLOR=0xff021254
# export ITEM_BG_COLOR=0xff093aa8
# export ACCENT_COLOR=0xff15bdf9

# -- Green Scheme --
# export BAR_COLOR=0xff003315
# export ITEM_BG_COLOR=0xff008c39
# export ACCENT_COLOR=0xff1dfca1

# -- Orange Scheme --
# export BAR_COLOR=0xff381c02
# export ITEM_BG_COLOR=0xff99440a
# export ACCENT_COLOR=0xfff97716

# -- Yellow Scheme --
# export BAR_COLOR=0xff2d2b02
# export ITEM_BG_COLOR=0xff8e7e0a
# export ACCENT_COLOR=0xfff7fc17
